'use strict';

const { App } = require('@slack/bolt');
require('dotenv').config();
const axios = require('axios');
const { Configuration, OpenAIApi } = require('openai');
// require the fs module that's built into Node.js
const fs = require('fs');
// get the raw data from the testDB.json file
let raw = fs.readFileSync('./testDB.json');
let rawLabDB = fs.readFileSync('./labDB.json');
// parse the raw bytes from the file as JSON
let faqs = JSON.parse(raw);
let labDB = JSON.parse(rawLabDB);


// Initializes your app with your bot token and signing secret
const app = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  socketMode: true, // enable the following to use socket mode
  appToken: process.env.APP_TOKEN,
});

const chatGPT = new OpenAIApi(
  new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
    model: 'gpt-3.5-turbo'
  })
);

// OpenAI API configuration
const openAIEndpoint = 'https://api.openai.com/v1/engines/davinci-codex/completions';
const openAIHeaders = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, // Replace with your OpenAI API key
};

// Define an empty array to store conversation history
let conversationHistory = [];

app.event('message', async ({ event, ack, say }) => {
  if (event.channel_type === 'im' && event.channel === 'D05CAEV2LL9') {
    console.log(event.text);
    console.log('event>>>>>', event);

    const configuration = new Configuration({
      apiKey: process.env.OPENAI_API_KEY,
      model: "text-davinci-003",
    });
    const openai = new OpenAIApi(configuration);

    // Combine conversation history and user message into a single prompt
    const prompt = conversationHistory.concat(event.text).join("\n");

    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt,
      temperature: 0,
      max_tokens: 100,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0.6,
      stop: ["###"],
    });

    // Extract the generated AI response from the OpenAI API response
    const aiResponse = response.data.choices[0].text;

    // Store the user message and AI response in the conversation history
    conversationHistory.push(`Human: ${event.text}`);
    conversationHistory.push(`AI: ${aiResponse}`);

    console.log(response.data.choices);
    say({
      text: aiResponse,
    });
  }
});


//!! PROOF OF LIFE MESSAGE
app.command('/hello', async ({ command, ack, say }) => {
  try {
    await ack();
    say('I am alive!!!');
  } catch (error) {
    console.log('err');
    // console.error(error);
  }
});

// users can access a faqs message from db we set up
app.command('/faqs', async ({ command, ack, say }) => {
  try {
    await ack();
    let message = { blocks: [] }; // adding string breaks the server, leave blank regardless of "error" in terminal
    faqs.data.map((faq) => {
      message.blocks.push(
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '*Question ❓*',
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: faq.question,
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '*Answer ✔️*',
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: faq.answer,
          },
        },
      );
    });
    say(message);
  } catch (error) {
    console.log('err');
    console.error(error);
  }
});


//grabs only two items from DB with keyword purpose
app.message(/purpose/, async ({ command, say }) => {
  try {
    let message = { blocks: [] }; // adding string 
    const purposeFAQs = faqs.data.filter((faq) => faq.keyword === 'purpose');

    purposeFAQs.map((faq) => {
      message.blocks.push(
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '*Question ❓*',
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: faq.question,
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '*Answer ✔️*',
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: faq.answer,
          },
        },
      );
    });

    say(message);
  } catch (error) {
    console.log('err');
    console.error(error);
  }
});

//allow users to update our faqs via bot
app.command('/update', async ({ command, ack, say }) => {
  try {
    await ack();
    const data = command.text.split('|');
    const newFAQ = {
      keyword: data[0].trim(),
      question: data[1].trim(),
      answer: data[2].trim(),
    };

    // save data to db.json
    fs.readFile('testDB.json', function (err, data) {
      const json = JSON.parse(data);
      json.data.push(newFAQ);
      fs.writeFile('testDB.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log('Successfully saved to testDB.json!');
      });
    });
    say(`You've added a new FAQ with the keyword *${newFAQ.keyword}.*`);
  } catch (error) {
    console.log('err');
    console.error(error);
  }
});

// testing simple message response
app.message(/hey/, async ({ command, say }) => { //regex to allow any type of string of hey work
  try {
    say('I noticed your hey, hey back.');
  } catch (error) {
    console.log('err');
    console.error(error);
  }
});

//help ai command test
app.command('/helpai', async ({ command, ack, say }) => {
  try {
    await ack();
    const response = await openAIChatCompletion(command.text);
    say(response);
  } catch (error) {
    console.error(error);
  }
});

// Function to process the OpenAI chat completion
async function openAIChatCompletion(message) {
  try {
    const response = await axios.post(openAIEndpoint, {
      prompt: message.text,
      max_tokens: 50,
      temperature: 0.7,
      n: 1,
    }, { headers: openAIHeaders });

    return response.data.choices[0].text.trim();
  } catch (error) {
    console.error('Error processing request with OpenAI:', error);
    return 'Oops! Something went wrong.';
  }
}


//start up our bot
(async () => {
  const port = process.env.PORT || 3002;
  // Start your app
  await app.start(process.env.PORT || port);
  console.log(`⚡️ Slack Bolt app is running on port ${port}!`);
})();

